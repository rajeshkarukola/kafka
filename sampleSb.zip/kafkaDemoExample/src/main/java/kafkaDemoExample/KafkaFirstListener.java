package kafkaDemoExample;

import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

@Configuration
public class KafkaFirstListener {

	@KafkaListener(topics = "firstTopic")
	public void listen(String message) {
	    System.out.println("Received Messasge in group foo: " + message);
	}
}
