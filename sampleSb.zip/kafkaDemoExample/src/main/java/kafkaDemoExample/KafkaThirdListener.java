package kafkaDemoExample;

import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;

@Configuration
public class KafkaThirdListener {

	@KafkaListener(topicPartitions 
			  = @TopicPartition(topic = "firstTopic", partitions = { "0", "1"}))
			public void listenToParition(
			  @Payload String message, 
			  @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition) {
			      System.out.println(
			        "Received Messasge: " + message +" from partition: " + partition);
			}
}
